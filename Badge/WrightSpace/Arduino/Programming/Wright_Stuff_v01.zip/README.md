# Programming the Wright Stuff

Programming can be accomlished by running the program_Wright_Stuff.sh 
script.

The script utlizies the esptool.py version 4.5.1
